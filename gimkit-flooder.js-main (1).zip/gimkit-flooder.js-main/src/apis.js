const apis = {
    roomId:'https://www.gimkit.com/api/matchmaker/find-info-from-code',
    checkPin: 'https://www.gimkit.com/api/matchmaker/find-info-from-code',
    matchMaker:'https://www.gimkit.com/api/matchmaker/join'
}

module.exports = apis